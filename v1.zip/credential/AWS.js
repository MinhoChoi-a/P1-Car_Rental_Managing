
exports.access = {
    accessKeyId: "AKIA5DWR6HFBLWIPCJPW",
    secretAccessKey: "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",
}


    
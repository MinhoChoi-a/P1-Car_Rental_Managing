
exports.mongoDB = 
    "mongodb+srv://admin:20200617@cluster0-xuivl.mongodb.net/Cars?retryWrites=true&w=majority";


